@include('common.header')
@include('common.footer')