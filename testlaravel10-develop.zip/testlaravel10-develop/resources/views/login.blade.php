@include('common.header')

<div class="container">
  <div class="row">
    <div class="col-sm-2 col-md-3"></div>
    <div class="col-12 col-sm-8 col-md-6">
      <form method="POST">
        <input type="hidden" name="_token" value="{{ csrf_token() }}">
        <div class="mb-3">
          <label class="form-label">Correo</label>
          <input name="EMAIL" type="email" class="form-control" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label class="form-label">Contraseña</label>
          <input name="PASSWORD" type="password" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Enviar</button>
      </form>
    </div>
    <div class="col-sm-2 col-md-3"></div>
  </div>
</div>

@include('common.footer')
